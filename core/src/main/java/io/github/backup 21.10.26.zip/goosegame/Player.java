
package io.github.goosegame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Shape2D;

public class Player {

    private float x;
    private float y;

    private int speed = 120;

    private Circle hitbox;

    public void draw(ShapeRenderer shapeRenderer) {
        shapeRenderer.setColor(1, 0, 0, 1);
        shapeRenderer.circle(x, y, 25, 8);
    }


    public boolean checkForCollisions(float x, float y, Array<WorldObject> worldObjects) {

        hitbox = new Circle(x, y, 25);
        

        for (WorldObject obj : worldObjects) {

            Shape2D other = obj.getHitbox();

            if (other instanceof Circle) {
                if (Intersector.overlaps((Circle) other, hitbox)) {
                    return false;
                }
            } else if (other instanceof Rectangle) {
                if (Intersector.overlaps(hitbox, (Rectangle) other)) {
                    return false;
                }
            }
        }

        return true;
    }


    public void update(float delta, Array<WorldObject> worldObjects) {

        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {

            if (checkForCollisions(x - (speed * delta), y, worldObjects)) {
                x -= speed * delta;
            }
        }

        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            
            if (checkForCollisions(x + (speed * delta), y, worldObjects)) {
                x += speed * delta;
            }

        }

        if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
           
            if (checkForCollisions(x, y + (speed * delta), worldObjects)) {
                y += speed * delta;
            }

        }

        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            
            if (checkForCollisions(x, y - (speed * delta), worldObjects)) {
                y -= speed * delta;
            }
        }
    }
    

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
}
