
package io.github.goosegame;

import io.github.goosegame.WorldObjects.Rock;
import io.github.goosegame.WorldObjects.Tree;

import com.badlogic.gdx.graphics.OrthographicCamera;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.viewport.FitViewport;


import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.Array;



// Screen requires show, render, resize, pause, resume, hide, dispose
public class GameScreen implements Screen {

    private SpriteBatch batch;
    private BitmapFont font;
    private ShapeRenderer shapeRenderer;

    private FitViewport viewport;

    // Camera type to follow the player instead of staying still at 0,0
    private OrthographicCamera camera;

    // Contains all the world objects that are added like a tree.
    private Array<WorldObject> worldObjects = new Array<>();

    private Player player;

    @Override
    public void show() {
        batch = new SpriteBatch();
        font = new BitmapFont();
        shapeRenderer = new ShapeRenderer();

        player = new Player();

        // Creates one world object.
        worldObjects.add(new Tree(300, 200, 20));
        worldObjects.add(new Tree(50, 600, 20));
        worldObjects.add(new Tree(350, 350, 20));
        worldObjects.add(new Rock(150, 100, 20));

        camera = new OrthographicCamera();
        viewport = new FitViewport(1280, 720, camera);
        viewport.apply();
    }

    @Override
    public void render(float delta) {

        // Reset screen
        Gdx.gl.glClearColor(39/255f, 110/255f, 58/255f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Update player and camera position.
        player.update(delta, worldObjects);
        camera.position.set(player.getX(), player.getY(), 0);
        camera.update();


        // Begin drawing
        batch.setProjectionMatrix(camera.combined);
        batch.begin();

        font.draw(batch, "Goose Game", 50, 300);
        font.draw(batch, "Use arrow keys to move!", 50, 260);

        batch.end();



        // Use shape renderer to draw objects
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        player.draw(shapeRenderer);

        // Iterate through each world object and draw it.
        for (WorldObject obj : worldObjects) {
            obj.draw(shapeRenderer);
        }

        // Finishes everything
        shapeRenderer.end();

    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        batch.dispose();
        font.dispose();
        shapeRenderer.dispose();
    }
}
