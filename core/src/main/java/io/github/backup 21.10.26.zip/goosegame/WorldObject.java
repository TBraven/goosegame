package io.github.goosegame;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Shape2D;

public class WorldObject {
    
    private float x = 100;
    private float y = 100;

    protected Shape2D hitbox;


    public WorldObject(int n_x, int n_y) {
        x = n_x;
        y = n_y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public Shape2D getHitbox() {
        return hitbox;
    }

    public void draw(ShapeRenderer shapeRenderer) {
        shapeRenderer.setColor(1, 0, 0, 1);
        shapeRenderer.circle(getX(), getY(), 5);
    }

    public void changeSize(int new_size) {
    }

    public void changePos(float n_x, float n_y) {
        x = n_x;
        y = n_y;
    }

    public Shape2D generateHitbox() {
        return null;
    }

}
